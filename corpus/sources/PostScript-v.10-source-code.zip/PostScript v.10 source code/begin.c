BEGIN(){ int i = 0; }
